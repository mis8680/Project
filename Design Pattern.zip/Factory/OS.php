<?php
    
abstract class OS
{
    public abstract function product();    
}
?>