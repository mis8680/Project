<?php

interface Car
{
    public function describe();
}

?>