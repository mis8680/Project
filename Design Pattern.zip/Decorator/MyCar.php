<?php

class MyCar implements Car
{
    public function describe()
    {
        print 'This is my car.';
    }
}

?>